﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Office.Interop.Excel;
using Microsoft.Vbe.Interop;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Net;
using System.Configuration;

namespace TicketManager_JeremiSzymkowiak_K19
{
    public partial class Main : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-F32T4QC;Initial Catalog=TicketManager;Integrated Security=True");
        public Main()
        {
            InitializeComponent();
        }

        private void btnSaveCust_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into CustomerDB(ID, client, contact, address, postcode, phone, email, website) Values (@ID, @client, @contact, @address, @postcode, @phone, @email, @website)";
            cmd.Parameters.AddWithValue("@ID", tbIDCust.Text);
            cmd.Parameters.AddWithValue("@client", tbClientCust.Text);
            cmd.Parameters.AddWithValue("@contact", tbContactCust.Text);
            cmd.Parameters.AddWithValue("@address", tbAddressCust.Text);
            cmd.Parameters.AddWithValue("@postcode", tbPostcodeCust.Text);
            cmd.Parameters.AddWithValue("@phone", tbPhoneCust.Text);

            cmd.Parameters.AddWithValue("@email", tbEmailCust.Text);

            cmd.Parameters.AddWithValue("@website", tbWebsiteCust.Text);



            cmd.ExecuteNonQuery();

            con.Close();

            disp_data();

            MessageBox.Show("Record added");



            tbIDCust.Text = "";

            tbClientCust.Text = "";

            tbContactCust.Text = "";

            tbAddressCust.Text = "";

            tbPostcodeCust.Text = "";

            tbPhoneCust.Text = "";

            tbEmailCust.Text = "";

            tbWebsiteCust.Text = "";
        }

        private void Main_Load(object sender, EventArgs e)
        {
            // TODO: Ten wiersz kodu wczytuje dane do tabeli 'ticketManagerDataSet3.techs' . Możesz go przenieść lub usunąć.
            this.techsTableAdapter.Fill(this.ticketManagerDataSet3.techs);
            disp_data();
        }
          

        private void btnDeleteClosed_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow selRow in dgvClosedTickets.SelectedRows.OfType<DataGridViewRow>().ToArray())

            {

                dgvClosedTickets.Rows.Remove(selRow);



                tbTotal.Text = (from DataGridViewRow row in dgvClosedTickets.Rows

                                where row.Cells[7].FormattedValue.ToString() != string.Empty

                                select Convert.ToDouble(row.Cells[7].FormattedValue)).Sum().ToString();



            }
        }
        public void disp_data()
        {

            con.Open();

            SqlCommand cmd = con.CreateCommand();

            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "select * from customerDB";

            System.Data.DataTable dt = new System.Data.DataTable();

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);

            dgvCustomerDB.DataSource = dt;

            con.Close();

        }
        

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click_1(object sender, EventArgs e)
        {
            string sql;

            sql = "Select * from customerDB where ID = '" + tbID.Text + "'";

            SqlCommand com = new SqlCommand(sql, con);

            con.Open();

            DataSet data = new DataSet();

            var adapter = new SqlDataAdapter(com);

            adapter.Fill(data);

            int count = data.Tables[0].Rows.Count;

            con.Close();

            if (count > 0)

            {

                tbClient.Text = data.Tables[0].Rows[0]["client"].ToString();

                tbAddress.Text = data.Tables[0].Rows[0]["address"].ToString();

                tbPost.Text = data.Tables[0].Rows[0]["postcode"].ToString();

                tbPhone.Text = data.Tables[0].Rows[0]["phone"].ToString();



            }

            else

            {

                MessageBox.Show("Invalid ID", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            dgvLiveTickets.Rows.Add(tbID.Text, tbClient.Text, tbAddress.Text, tbPost.Text, tbPhone.Text, cbTech.Text, rtbDescription.Text, tbEstimate.Text, monthCalendar1.SelectionRange.Start.ToShortDateString());



            tbID.Text = "";

            tbClient.Text = "";

            tbAddress.Text = "";

            tbPost.Text = "";

            tbPhone.Text = "";

            rtbDescription.Text = "";

            cbTech.Text = "";

            tbEstimate.Text = "";
        }

        private void btnDeleteLive_Click_1(object sender, EventArgs e)
        {
            foreach (DataGridViewRow selRow in dgvLiveTickets.SelectedRows.OfType<DataGridViewRow>().ToArray())

            {

                dgvLiveTickets.Rows.Remove(selRow);

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow selRow in dgvLiveTickets.SelectedRows.OfType<DataGridViewRow>().ToArray())

            {

                dgvLiveTickets.Rows.Remove(selRow);

                dgvClosedTickets.Rows.Add(selRow);



                tbTotal.Text = (from DataGridViewRow row in dgvClosedTickets.Rows

                                where row.Cells[7].FormattedValue.ToString() != string.Empty

                                select Convert.ToDouble(row.Cells[7].FormattedValue)).Sum().ToString();



            }
        }

        private void btnExcel_Click_1(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();

            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);

            Microsoft.Office.Interop.Excel._Worksheet

            worksheet = null;

            app.Visible = true;

            worksheet = workbook.Sheets["Arkusz1"];

            worksheet = workbook.ActiveSheet;

            worksheet.Name = "Exported from Ticket Manager";



            for (int i = 1; i < dgvClosedTickets.Columns.Count + 1; i++)

            {

                worksheet.Cells[1, i] = dgvClosedTickets.Columns[i - 1].HeaderText;

            }



            for (int i = 0; i < dgvClosedTickets.Rows.Count - 1; i++)

            {

                for (int j = 0; j < dgvClosedTickets.Columns.Count; j++)

                {

                    worksheet.Cells[i + 2, j + 1] = dgvClosedTickets.Rows[i].Cells[j].Value.ToString();

                }

            }



            workbook.SaveAs("C:\\Users\\Gabriel\\Documents\\ClosedTickets.xlsx", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing,

                Type.Missing, Type.Missing);


        }

        private void LogOut1_Click_1(object sender, EventArgs e)
        {

            this.Hide();

            Login loginPg = new Login();

            loginPg.Show();
        }
    }
}


