﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace TicketManager_JeremiSzymkowiak_K19
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            // TODO: Ten wiersz kodu wczytuje dane do tabeli 'ticketManagerDataSet.users' . Możesz go przenieść lub usunąć.
            this.usersTableAdapter.Fill(this.ticketManagerDataSet.users);

        }

        private void cbUsername_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-F32T4QC;Initial Catalog=TicketManager;Integrated Security=True");

            String query = "select * from users where username = '" + cbUsername.Text.Trim() + "' and password = '" + tbPassword.Text.Trim() + "'";

            SqlDataAdapter sda = new SqlDataAdapter(query, sqlCon);

            DataTable dtbl = new DataTable();

            sda.Fill(dtbl);

            if (dtbl.Rows.Count == 1)

            {

                MessageBox.Show("Welcome to Ticket Manager " +cbUsername.Text);



                Main objMain = new Main();
                this.Hide();
                objMain.Show();
            }
            else
            {

                MessageBox.Show("Incorrect username or password entered!");

            }
        }
    }
}
