﻿namespace TicketManager_JeremiSzymkowiak_K19
{
    partial class Main
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.LogOut1 = new System.Windows.Forms.Button();
            this.btnDeleteLive = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.cbTech = new System.Windows.Forms.ComboBox();
            this.techsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ticketManagerDataSet3 = new TicketManager_JeremiSzymkowiak_K19.TicketManagerDataSet3();
            this.label10 = new System.Windows.Forms.Label();
            this.tbEstimate = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rtbDescription = new System.Windows.Forms.RichTextBox();
            this.tbClient = new System.Windows.Forms.TextBox();
            this.tbAddress = new System.Windows.Forms.TextBox();
            this.tbPost = new System.Windows.Forms.TextBox();
            this.tbPhone = new System.Windows.Forms.TextBox();
            this.tbID = new System.Windows.Forms.TextBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvLiveTickets = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Client = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Postcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tech = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estimate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnDeleteClosed = new System.Windows.Forms.Button();
            this.btnExcel = new System.Windows.Forms.Button();
            this.tbTotal = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dgvClosedTickets = new System.Windows.Forms.DataGridView();
            this.CustID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClientName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Add = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Post = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TechName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Desc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.data = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnSaveCust = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.tbPhoneCust = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tbEmailCust = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tbWebsiteCust = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tbClientCust = new System.Windows.Forms.TextBox();
            this.tbContactCust = new System.Windows.Forms.TextBox();
            this.tbAddressCust = new System.Windows.Forms.TextBox();
            this.tbPostcodeCust = new System.Windows.Forms.TextBox();
            this.tbIDCust = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dgvCustomerDB = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.postcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.websiteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerDBBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ticketManagerDataSet1 = new TicketManager_JeremiSzymkowiak_K19.TicketManagerDataSet1();
            this.ticketManagerDataSet = new TicketManager_JeremiSzymkowiak_K19.TicketManagerDataSet();
            this.ticketManagerDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customerDBTableAdapter = new TicketManager_JeremiSzymkowiak_K19.TicketManagerDataSet1TableAdapters.customerDBTableAdapter();
            this.techsTableAdapter = new TicketManager_JeremiSzymkowiak_K19.TicketManagerDataSet3TableAdapters.techsTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.techsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ticketManagerDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLiveTickets)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClosedTickets)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerDB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDBBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ticketManagerDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ticketManagerDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ticketManagerDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(1, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1899, 893);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.LogOut1);
            this.tabPage1.Controls.Add(this.btnDeleteLive);
            this.tabPage1.Controls.Add(this.btnClose);
            this.tabPage1.Controls.Add(this.btnSave);
            this.tabPage1.Controls.Add(this.btnSearch);
            this.tabPage1.Controls.Add(this.cbTech);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.tbEstimate);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.rtbDescription);
            this.tabPage1.Controls.Add(this.tbClient);
            this.tabPage1.Controls.Add(this.tbAddress);
            this.tabPage1.Controls.Add(this.tbPost);
            this.tabPage1.Controls.Add(this.tbPhone);
            this.tabPage1.Controls.Add(this.tbID);
            this.tabPage1.Controls.Add(this.monthCalendar1);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.dgvLiveTickets);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1891, 864);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Live Tickets";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // LogOut1
            // 
            this.LogOut1.AutoSize = true;
            this.LogOut1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.LogOut1.Location = new System.Drawing.Point(1623, 17);
            this.LogOut1.Name = "LogOut1";
            this.LogOut1.Size = new System.Drawing.Size(69, 27);
            this.LogOut1.TabIndex = 26;
            this.LogOut1.Text = "Log Out";
            this.LogOut1.UseVisualStyleBackColor = true;
            this.LogOut1.Click += new System.EventHandler(this.LogOut1_Click_1);
            // 
            // btnDeleteLive
            // 
            this.btnDeleteLive.AutoSize = true;
            this.btnDeleteLive.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btnDeleteLive.Location = new System.Drawing.Point(964, 799);
            this.btnDeleteLive.Name = "btnDeleteLive";
            this.btnDeleteLive.Size = new System.Drawing.Size(184, 41);
            this.btnDeleteLive.TabIndex = 25;
            this.btnDeleteLive.Text = "Delete Ticket";
            this.btnDeleteLive.UseVisualStyleBackColor = true;
            this.btnDeleteLive.Click += new System.EventHandler(this.btnDeleteLive_Click_1);
            // 
            // btnClose
            // 
            this.btnClose.AutoSize = true;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btnClose.Location = new System.Drawing.Point(783, 799);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(175, 41);
            this.btnClose.TabIndex = 24;
            this.btnClose.Text = "Close Ticket";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSave
            // 
            this.btnSave.AutoSize = true;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btnSave.Location = new System.Drawing.Point(1552, 769);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(86, 41);
            this.btnSave.TabIndex = 22;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.AutoSize = true;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btnSearch.Location = new System.Drawing.Point(1436, 769);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(110, 41);
            this.btnSearch.TabIndex = 20;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click_1);
            // 
            // cbTech
            // 
            this.cbTech.DataSource = this.techsBindingSource;
            this.cbTech.DisplayMember = "techName";
            this.cbTech.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.cbTech.FormattingEnabled = true;
            this.cbTech.Location = new System.Drawing.Point(1385, 500);
            this.cbTech.Name = "cbTech";
            this.cbTech.Size = new System.Drawing.Size(227, 37);
            this.cbTech.TabIndex = 6;
            this.cbTech.ValueMember = "techName";
            // 
            // techsBindingSource
            // 
            this.techsBindingSource.DataMember = "techs";
            this.techsBindingSource.DataSource = this.ticketManagerDataSet3;
            // 
            // ticketManagerDataSet3
            // 
            this.ticketManagerDataSet3.DataSetName = "TicketManagerDataSet3";
            this.ticketManagerDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label10.Location = new System.Drawing.Point(1211, 506);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(153, 31);
            this.label10.TabIndex = 17;
            this.label10.Text = " Technician";
            // 
            // tbEstimate
            // 
            this.tbEstimate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbEstimate.Location = new System.Drawing.Point(1192, 773);
            this.tbEstimate.Name = "tbEstimate";
            this.tbEstimate.Size = new System.Drawing.Size(112, 34);
            this.tbEstimate.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label9.Location = new System.Drawing.Point(1310, 774);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 31);
            this.label9.TabIndex = 15;
            this.label9.Text = "Estimate";
            // 
            // rtbDescription
            // 
            this.rtbDescription.Location = new System.Drawing.Point(1228, 599);
            this.rtbDescription.Name = "rtbDescription";
            this.rtbDescription.Size = new System.Drawing.Size(410, 144);
            this.rtbDescription.TabIndex = 7;
            this.rtbDescription.Text = "";
            // 
            // tbClient
            // 
            this.tbClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbClient.Location = new System.Drawing.Point(1385, 344);
            this.tbClient.Name = "tbClient";
            this.tbClient.Size = new System.Drawing.Size(227, 34);
            this.tbClient.TabIndex = 2;
            // 
            // tbAddress
            // 
            this.tbAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbAddress.Location = new System.Drawing.Point(1385, 383);
            this.tbAddress.Name = "tbAddress";
            this.tbAddress.Size = new System.Drawing.Size(227, 34);
            this.tbAddress.TabIndex = 3;
            // 
            // tbPost
            // 
            this.tbPost.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbPost.Location = new System.Drawing.Point(1385, 422);
            this.tbPost.Name = "tbPost";
            this.tbPost.Size = new System.Drawing.Size(227, 34);
            this.tbPost.TabIndex = 4;
            // 
            // tbPhone
            // 
            this.tbPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbPhone.Location = new System.Drawing.Point(1385, 461);
            this.tbPhone.Name = "tbPhone";
            this.tbPhone.Size = new System.Drawing.Size(227, 34);
            this.tbPhone.TabIndex = 5;
            // 
            // tbID
            // 
            this.tbID.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbID.Location = new System.Drawing.Point(1385, 302);
            this.tbID.Name = "tbID";
            this.tbID.Size = new System.Drawing.Size(60, 34);
            this.tbID.TabIndex = 1;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(1352, 54);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label8.Location = new System.Drawing.Point(1221, 571);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(151, 31);
            this.label8.TabIndex = 7;
            this.label8.Text = "Description";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label7.Location = new System.Drawing.Point(1236, 425);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 31);
            this.label7.TabIndex = 6;
            this.label7.Text = "Postcode";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label6.Location = new System.Drawing.Point(1250, 384);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 31);
            this.label6.TabIndex = 5;
            this.label6.Text = "Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label5.Location = new System.Drawing.Point(1272, 464);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 31);
            this.label5.TabIndex = 5;
            this.label5.Text = "Phone";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label4.Location = new System.Drawing.Point(1280, 345);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 31);
            this.label4.TabIndex = 4;
            this.label4.Text = "Client";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label3.Location = new System.Drawing.Point(1322, 303);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 31);
            this.label3.TabIndex = 3;
            this.label3.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label2.Location = new System.Drawing.Point(1211, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 31);
            this.label2.TabIndex = 2;
            this.label2.Text = "Date Due";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label1.Location = new System.Drawing.Point(41, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Live Tickets";
            // 
            // dgvLiveTickets
            // 
            this.dgvLiveTickets.BackgroundColor = System.Drawing.Color.Wheat;
            this.dgvLiveTickets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLiveTickets.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Client,
            this.Address,
            this.Postcode,
            this.Phone,
            this.Tech,
            this.Description,
            this.Estimate,
            this.Date});
            this.dgvLiveTickets.Location = new System.Drawing.Point(41, 43);
            this.dgvLiveTickets.Name = "dgvLiveTickets";
            this.dgvLiveTickets.RowHeadersWidth = 51;
            this.dgvLiveTickets.RowTemplate.Height = 25;
            this.dgvLiveTickets.Size = new System.Drawing.Size(1107, 750);
            this.dgvLiveTickets.TabIndex = 0;
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.MinimumWidth = 6;
            this.ID.Name = "ID";
            this.ID.Width = 125;
            // 
            // Client
            // 
            this.Client.HeaderText = "Client";
            this.Client.MinimumWidth = 6;
            this.Client.Name = "Client";
            this.Client.Width = 125;
            // 
            // Address
            // 
            this.Address.HeaderText = "Address";
            this.Address.MinimumWidth = 6;
            this.Address.Name = "Address";
            this.Address.Width = 125;
            // 
            // Postcode
            // 
            this.Postcode.HeaderText = "Postcode";
            this.Postcode.MinimumWidth = 6;
            this.Postcode.Name = "Postcode";
            this.Postcode.Width = 125;
            // 
            // Phone
            // 
            this.Phone.HeaderText = "Phone";
            this.Phone.MinimumWidth = 6;
            this.Phone.Name = "Phone";
            this.Phone.Width = 125;
            // 
            // Tech
            // 
            this.Tech.HeaderText = "Tech";
            this.Tech.MinimumWidth = 6;
            this.Tech.Name = "Tech";
            this.Tech.Width = 125;
            // 
            // Description
            // 
            this.Description.HeaderText = "Description";
            this.Description.MinimumWidth = 6;
            this.Description.Name = "Description";
            this.Description.Width = 125;
            // 
            // Estimate
            // 
            this.Estimate.HeaderText = "Estimate";
            this.Estimate.MinimumWidth = 6;
            this.Estimate.Name = "Estimate";
            this.Estimate.Visible = false;
            this.Estimate.Width = 125;
            // 
            // Date
            // 
            this.Date.HeaderText = "Date Due";
            this.Date.MinimumWidth = 6;
            this.Date.Name = "Date";
            this.Date.Width = 125;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnDeleteClosed);
            this.tabPage2.Controls.Add(this.btnExcel);
            this.tabPage2.Controls.Add(this.tbTotal);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.dgvClosedTickets);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1891, 864);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Closed Tickiets";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnDeleteClosed
            // 
            this.btnDeleteClosed.AutoSize = true;
            this.btnDeleteClosed.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btnDeleteClosed.Location = new System.Drawing.Point(1115, 812);
            this.btnDeleteClosed.Name = "btnDeleteClosed";
            this.btnDeleteClosed.Size = new System.Drawing.Size(154, 41);
            this.btnDeleteClosed.TabIndex = 26;
            this.btnDeleteClosed.Text = "Delete";
            this.btnDeleteClosed.UseVisualStyleBackColor = true;
            this.btnDeleteClosed.Click += new System.EventHandler(this.btnDeleteClosed_Click);
            // 
            // btnExcel
            // 
            this.btnExcel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExcel.BackgroundImage")));
            this.btnExcel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnExcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btnExcel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnExcel.Location = new System.Drawing.Point(1345, 247);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(168, 86);
            this.btnExcel.TabIndex = 24;
            this.btnExcel.UseVisualStyleBackColor = true;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click_1);
            // 
            // tbTotal
            // 
            this.tbTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbTotal.Location = new System.Drawing.Point(1309, 70);
            this.tbTotal.Name = "tbTotal";
            this.tbTotal.Size = new System.Drawing.Size(227, 34);
            this.tbTotal.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label12.Location = new System.Drawing.Point(1309, 41);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(190, 31);
            this.label12.TabIndex = 14;
            this.label12.Text = "Total invoiced:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label11.Location = new System.Drawing.Point(41, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(194, 31);
            this.label11.TabIndex = 3;
            this.label11.Text = "Closed Tickets";
            // 
            // dgvClosedTickets
            // 
            this.dgvClosedTickets.BackgroundColor = System.Drawing.Color.Wheat;
            this.dgvClosedTickets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvClosedTickets.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CustID,
            this.ClientName,
            this.Add,
            this.Post,
            this.number,
            this.TechName,
            this.Desc,
            this.Price,
            this.data});
            this.dgvClosedTickets.Location = new System.Drawing.Point(41, 43);
            this.dgvClosedTickets.Name = "dgvClosedTickets";
            this.dgvClosedTickets.RowHeadersWidth = 51;
            this.dgvClosedTickets.RowTemplate.Height = 25;
            this.dgvClosedTickets.Size = new System.Drawing.Size(1228, 758);
            this.dgvClosedTickets.TabIndex = 2;
            // 
            // CustID
            // 
            this.CustID.HeaderText = "ID";
            this.CustID.MinimumWidth = 6;
            this.CustID.Name = "CustID";
            this.CustID.Width = 125;
            // 
            // ClientName
            // 
            this.ClientName.HeaderText = "Client";
            this.ClientName.MinimumWidth = 6;
            this.ClientName.Name = "ClientName";
            this.ClientName.Width = 125;
            // 
            // Add
            // 
            this.Add.HeaderText = "Address";
            this.Add.MinimumWidth = 6;
            this.Add.Name = "Add";
            this.Add.Width = 125;
            // 
            // Post
            // 
            this.Post.HeaderText = "Postcode";
            this.Post.MinimumWidth = 6;
            this.Post.Name = "Post";
            this.Post.Width = 125;
            // 
            // number
            // 
            this.number.HeaderText = "Phone";
            this.number.MinimumWidth = 6;
            this.number.Name = "number";
            this.number.Width = 125;
            // 
            // TechName
            // 
            this.TechName.HeaderText = "Tech";
            this.TechName.MinimumWidth = 6;
            this.TechName.Name = "TechName";
            this.TechName.Width = 125;
            // 
            // Desc
            // 
            this.Desc.HeaderText = "Description";
            this.Desc.MinimumWidth = 6;
            this.Desc.Name = "Desc";
            this.Desc.Width = 125;
            // 
            // Price
            // 
            this.Price.HeaderText = "Price";
            this.Price.MinimumWidth = 6;
            this.Price.Name = "Price";
            this.Price.Width = 125;
            // 
            // data
            // 
            this.data.HeaderText = "Date";
            this.data.MinimumWidth = 6;
            this.data.Name = "data";
            this.data.Visible = false;
            this.data.Width = 125;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnSaveCust);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.tbPhoneCust);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.tbEmailCust);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.tbWebsiteCust);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.tbClientCust);
            this.tabPage3.Controls.Add(this.tbContactCust);
            this.tabPage3.Controls.Add(this.tbAddressCust);
            this.tabPage3.Controls.Add(this.tbPostcodeCust);
            this.tabPage3.Controls.Add(this.tbIDCust);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.dgvCustomerDB);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1891, 864);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Customer Database";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnSaveCust
            // 
            this.btnSaveCust.AutoSize = true;
            this.btnSaveCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.btnSaveCust.Location = new System.Drawing.Point(1534, 508);
            this.btnSaveCust.Name = "btnSaveCust";
            this.btnSaveCust.Size = new System.Drawing.Size(86, 41);
            this.btnSaveCust.TabIndex = 43;
            this.btnSaveCust.Text = "Save";
            this.btnSaveCust.UseVisualStyleBackColor = true;
            this.btnSaveCust.Click += new System.EventHandler(this.btnSaveCust_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.label13.Location = new System.Drawing.Point(1339, 87);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(316, 39);
            this.label13.TabIndex = 42;
            this.label13.Text = "Add new  customer:";
            // 
            // tbPhoneCust
            // 
            this.tbPhoneCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbPhoneCust.Location = new System.Drawing.Point(1393, 374);
            this.tbPhoneCust.Name = "tbPhoneCust";
            this.tbPhoneCust.Size = new System.Drawing.Size(227, 34);
            this.tbPhoneCust.TabIndex = 41;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label23.Location = new System.Drawing.Point(1282, 373);
            this.label23.Name = "label23";
            this.label23.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label23.Size = new System.Drawing.Size(92, 31);
            this.label23.TabIndex = 40;
            this.label23.Text = "Phone";
            // 
            // tbEmailCust
            // 
            this.tbEmailCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbEmailCust.Location = new System.Drawing.Point(1393, 413);
            this.tbEmailCust.Name = "tbEmailCust";
            this.tbEmailCust.Size = new System.Drawing.Size(227, 34);
            this.tbEmailCust.TabIndex = 39;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label22.Location = new System.Drawing.Point(1291, 413);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(81, 31);
            this.label22.TabIndex = 38;
            this.label22.Text = "Email";
            // 
            // tbWebsiteCust
            // 
            this.tbWebsiteCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbWebsiteCust.Location = new System.Drawing.Point(1393, 452);
            this.tbWebsiteCust.Name = "tbWebsiteCust";
            this.tbWebsiteCust.Size = new System.Drawing.Size(227, 34);
            this.tbWebsiteCust.TabIndex = 37;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label21.Location = new System.Drawing.Point(1266, 452);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(112, 31);
            this.label21.TabIndex = 36;
            this.label21.Text = "Website";
            // 
            // tbClientCust
            // 
            this.tbClientCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbClientCust.Location = new System.Drawing.Point(1393, 218);
            this.tbClientCust.Name = "tbClientCust";
            this.tbClientCust.Size = new System.Drawing.Size(227, 34);
            this.tbClientCust.TabIndex = 31;
            // 
            // tbContactCust
            // 
            this.tbContactCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbContactCust.Location = new System.Drawing.Point(1393, 257);
            this.tbContactCust.Name = "tbContactCust";
            this.tbContactCust.Size = new System.Drawing.Size(227, 34);
            this.tbContactCust.TabIndex = 30;
            // 
            // tbAddressCust
            // 
            this.tbAddressCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbAddressCust.Location = new System.Drawing.Point(1393, 296);
            this.tbAddressCust.Name = "tbAddressCust";
            this.tbAddressCust.Size = new System.Drawing.Size(227, 34);
            this.tbAddressCust.TabIndex = 29;
            // 
            // tbPostcodeCust
            // 
            this.tbPostcodeCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbPostcodeCust.Location = new System.Drawing.Point(1393, 335);
            this.tbPostcodeCust.Name = "tbPostcodeCust";
            this.tbPostcodeCust.Size = new System.Drawing.Size(227, 34);
            this.tbPostcodeCust.TabIndex = 28;
            // 
            // tbIDCust
            // 
            this.tbIDCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.tbIDCust.Location = new System.Drawing.Point(1393, 174);
            this.tbIDCust.Name = "tbIDCust";
            this.tbIDCust.Size = new System.Drawing.Size(60, 34);
            this.tbIDCust.TabIndex = 27;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label14.Location = new System.Drawing.Point(1264, 295);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(114, 31);
            this.label14.TabIndex = 26;
            this.label14.Text = "Address";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label15.Location = new System.Drawing.Point(1268, 257);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(109, 31);
            this.label15.TabIndex = 24;
            this.label15.Text = "Contact";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label16.Location = new System.Drawing.Point(1253, 336);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(128, 31);
            this.label16.TabIndex = 25;
            this.label16.Text = "Postcode";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label17.Location = new System.Drawing.Point(1288, 218);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(84, 31);
            this.label17.TabIndex = 23;
            this.label17.Text = "Client";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label18.Location = new System.Drawing.Point(1322, 173);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(42, 31);
            this.label18.TabIndex = 22;
            this.label18.Text = "ID";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.label19.Location = new System.Drawing.Point(41, 10);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(251, 31);
            this.label19.TabIndex = 21;
            this.label19.Text = "Customer database";
            // 
            // dgvCustomerDB
            // 
            this.dgvCustomerDB.AutoGenerateColumns = false;
            this.dgvCustomerDB.BackgroundColor = System.Drawing.Color.Wheat;
            this.dgvCustomerDB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomerDB.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.clientDataGridViewTextBoxColumn,
            this.contactDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.postcodeDataGridViewTextBoxColumn,
            this.phoneDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.websiteDataGridViewTextBoxColumn});
            this.dgvCustomerDB.DataSource = this.customerDBBindingSource;
            this.dgvCustomerDB.Location = new System.Drawing.Point(41, 43);
            this.dgvCustomerDB.Name = "dgvCustomerDB";
            this.dgvCustomerDB.RowHeadersWidth = 51;
            this.dgvCustomerDB.RowTemplate.Height = 25;
            this.dgvCustomerDB.Size = new System.Drawing.Size(1193, 614);
            this.dgvCustomerDB.TabIndex = 20;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.Width = 125;
            // 
            // clientDataGridViewTextBoxColumn
            // 
            this.clientDataGridViewTextBoxColumn.DataPropertyName = "client";
            this.clientDataGridViewTextBoxColumn.HeaderText = "client";
            this.clientDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.clientDataGridViewTextBoxColumn.Name = "clientDataGridViewTextBoxColumn";
            this.clientDataGridViewTextBoxColumn.Width = 125;
            // 
            // contactDataGridViewTextBoxColumn
            // 
            this.contactDataGridViewTextBoxColumn.DataPropertyName = "contact";
            this.contactDataGridViewTextBoxColumn.HeaderText = "contact";
            this.contactDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.contactDataGridViewTextBoxColumn.Name = "contactDataGridViewTextBoxColumn";
            this.contactDataGridViewTextBoxColumn.Width = 125;
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "address";
            this.addressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            this.addressDataGridViewTextBoxColumn.Width = 125;
            // 
            // postcodeDataGridViewTextBoxColumn
            // 
            this.postcodeDataGridViewTextBoxColumn.DataPropertyName = "postcode";
            this.postcodeDataGridViewTextBoxColumn.HeaderText = "postcode";
            this.postcodeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.postcodeDataGridViewTextBoxColumn.Name = "postcodeDataGridViewTextBoxColumn";
            this.postcodeDataGridViewTextBoxColumn.Width = 125;
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            this.phoneDataGridViewTextBoxColumn.DataPropertyName = "phone";
            this.phoneDataGridViewTextBoxColumn.HeaderText = "phone";
            this.phoneDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            this.phoneDataGridViewTextBoxColumn.Width = 125;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "email";
            this.emailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.Width = 125;
            // 
            // websiteDataGridViewTextBoxColumn
            // 
            this.websiteDataGridViewTextBoxColumn.DataPropertyName = "website";
            this.websiteDataGridViewTextBoxColumn.HeaderText = "website";
            this.websiteDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.websiteDataGridViewTextBoxColumn.Name = "websiteDataGridViewTextBoxColumn";
            this.websiteDataGridViewTextBoxColumn.Width = 125;
            // 
            // customerDBBindingSource
            // 
            this.customerDBBindingSource.DataMember = "customerDB";
            this.customerDBBindingSource.DataSource = this.ticketManagerDataSet1;
            // 
            // ticketManagerDataSet1
            // 
            this.ticketManagerDataSet1.DataSetName = "TicketManagerDataSet1";
            this.ticketManagerDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ticketManagerDataSet
            // 
            this.ticketManagerDataSet.DataSetName = "TicketManagerDataSet";
            this.ticketManagerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ticketManagerDataSetBindingSource
            // 
            this.ticketManagerDataSetBindingSource.DataSource = this.ticketManagerDataSet;
            this.ticketManagerDataSetBindingSource.Position = 0;
            // 
            // customerDBTableAdapter
            // 
            this.customerDBTableAdapter.ClearBeforeFill = true;
            // 
            // techsTableAdapter
            // 
            this.techsTableAdapter.ClearBeforeFill = true;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1702, 911);
            this.Controls.Add(this.tabControl1);
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.techsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ticketManagerDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLiveTickets)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClosedTickets)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerDB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDBBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ticketManagerDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ticketManagerDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ticketManagerDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button LogOut1;
        private System.Windows.Forms.Button btnDeleteLive;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.ComboBox cbTech;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbEstimate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox rtbDescription;
        private System.Windows.Forms.TextBox tbClient;
        private System.Windows.Forms.TextBox tbAddress;
        private System.Windows.Forms.TextBox tbPost;
        private System.Windows.Forms.TextBox tbPhone;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvLiveTickets;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnDeleteClosed;
        private System.Windows.Forms.Button btnExcel;
        private System.Windows.Forms.TextBox tbTotal;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dgvClosedTickets;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnSaveCust;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbPhoneCust;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tbEmailCust;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tbWebsiteCust;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tbClientCust;
        private System.Windows.Forms.TextBox tbContactCust;
        private System.Windows.Forms.TextBox tbAddressCust;
        private System.Windows.Forms.TextBox tbPostcodeCust;
        private System.Windows.Forms.TextBox tbIDCust;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DataGridView dgvCustomerDB;
        private System.Windows.Forms.BindingSource ticketManagerDataSetBindingSource;
        private TicketManagerDataSet ticketManagerDataSet;
        private TicketManagerDataSet1 ticketManagerDataSet1;
        private System.Windows.Forms.BindingSource customerDBBindingSource;
        private TicketManagerDataSet1TableAdapters.customerDBTableAdapter customerDBTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn postcodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn websiteDataGridViewTextBoxColumn;
        private TicketManagerDataSet3 ticketManagerDataSet3;
        private System.Windows.Forms.BindingSource techsBindingSource;
        private TicketManagerDataSet3TableAdapters.techsTableAdapter techsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Client;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn Postcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tech;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estimate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClientName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Add;
        private System.Windows.Forms.DataGridViewTextBoxColumn Post;
        private System.Windows.Forms.DataGridViewTextBoxColumn number;
        private System.Windows.Forms.DataGridViewTextBoxColumn TechName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Desc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn data;
    }
}

