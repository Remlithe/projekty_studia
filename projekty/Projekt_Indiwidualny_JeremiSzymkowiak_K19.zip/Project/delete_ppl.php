<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project_bd_jeremi</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.google.com/specimen/Roboto?query=roboto' rel='stylesheet' type='text/css'>
</head>
<body>
<?php
include('bd.php');

if(isset($_GET['id'])){
    $id=$_GET['id'];
    $sql = "DELETE FROM klienci WHERE Id_Klienta=$id";
    if(mysqli_query($connect, $sql)){
        echo "<h3 class = 'deleteinfo'>the row was deleted</h3>";
    } else
    {
        echo "An error accured in the middle of deleting the row";
    }
}
mysqli_close($connect);
?>
<button type="button" class="button" onclick="location.href= 'index.php' ">powrót na stronę główną</button>
</body>
</html>