<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project_bd_jeremi</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.google.com/specimen/Roboto?query=roboto' rel='stylesheet' type='text/css'>
</head>
<body>
<?php

include('bd.php');

if(isset($_GET['id'])){
    $id =$_GET['id'];
    $query = "SELECT * FROM samochody WHERE Nr_rejestracyjny = '$id'";
    $result =  mysqli_query($connect, $query);
    $row = mysqli_fetch_assoc($result);
    $fields = mysqli_fetch_fields($result);
    foreach($fields as $field){
        $columnNames[]= $field->name;
    }
}
else
    {
        echo "An error accured";
    }

    if(isset($_POST['Edit']) ){
        $id = $_POST['id'];
        $Model = strip_tags($_POST['model']);
        $Marka = strip_tags($_POST['marka']);
        $Data_produkcji = strip_tags($_POST['date']);
        $Czy_dostepny = strip_tags($_POST['aviable']);
        
            $sql = "UPDATE samochody SET Model = '$Model', Marka = '$Marka', Rok_produkcji = '$Data_produkcji', Czy_dostepny = '$Czy_dostepny' WHERE Nr_rejestracyjny = '$id'";
        
    
        if(mysqli_query($connect,$sql)){
            echo "Record was edited succesfully";
        }else {
            echo "Error while editing sccesfully";
        }
        header("Location: edit_car.php");
    }
 
?>


<form class = "panel" action="<?php echo $_SERVER['PHP_SELF'];?>" method= "POST">
<h1>Edycja samochodu :</h1>
<div class = "inputadjust"
>
    <input type="text" name="model" value= "<?php echo $row[$columnNames[1]];?>">
    <br>
    <input type="text" name="marka" value="<?php echo $row[$columnNames[2]];?>">
    <br>
    <input  type="text" name = "date" value="<?php echo $row[$columnNames[3]];?>">
    <br>
    <input  type="text" name = "aviable" value="<?php echo $row[$columnNames[4]];?>" maxlength = "3">
    <br>
    <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>"> 
</div>
<div class = "adjust">
    <input type="submit" class="button" name="Edit" value="Finish">
    
<button type="button" class="button" onclick="location.href= 'edit_car.php' ">powrót</button>
</div>

</from>
</body>
</html>
