<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project_bd_jeremi</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.google.com/specimen/Roboto?query=roboto' rel='stylesheet' type='text/css'>
    <div class="header"><h3> PANEL UŻYTKOWNIKA </h3></div>
</head>
<body>
<form class = "panel" action="<?php echo $_SERVER['PHP_SELF'];?>" method= "POST">
<h3>Pokaż dane:</h3>
<div class = "inputadjust">
<select name="table">
    <option value="klienci"> klienci </option>
    <option value="samochody"> samochody </option>
    <option value="wypozyczenia"> wypozyczenia </option>
</select>
    <input type="text" name="columns" placeholder="Jakie kolumny pokazać">
</div>
    <input type="submit" class="smallbutton" name="view" value="Pokaż">
<div class = "table">
<?php

include("bd.php");

if(isset($_POST['view'])){

    $columns = $_POST['columns']; 

    $table = $_POST['table'];

    $sql = "SELECT $columns FROM $table"; 

    
  $result = mysqli_query($connect, $sql);
    echo "<table border='1'>";
    echo "<tr>"; 
   foreach ($row = mysqli_fetch_fields($result)as $field) { 
       echo "<th>".$field ->name."</th>"; 
   } 
   echo "</tr>";
   
    while ($row = mysqli_fetch_assoc($result)) { 
        
       echo "<tr>"; 
       foreach ($row as $value) { 
           echo "<td>$value</td>"; 
       } 
       echo "</tr>"; 
    }
    echo "</table>"; 

    
    
}
    ?>
</div>
<button type="button" class="button" onclick="location.href= 'Login.php' ">zaloguj się</button>
</form>
</body>
</html>
