<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project_bd_jeremi</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.google.com/specimen/Roboto?query=roboto' rel='stylesheet' type='text/css'>
</head>
<body>
<div class = "table">
<?php
    
    include("bd.php");

    $sql = "SELECT * FROM samochody";
    $result =  mysqli_query($connect, $sql);

    $fields = mysqli_fetch_fields($result);
    foreach($fields as $field){
        $columnNames[]= $field->name;
    }
    if ($result->num_rows > 0) {
        echo "<table border='1'>";
         echo "<tr>"; 
         
        echo "<th>Edycja</th>";
        echo "<th>Usuwanie</th>";
        foreach ($row = mysqli_fetch_fields($result)as $field) { 
            echo "<th>".$field ->name."</th>"; 
        } 
        echo "</tr>";

    while ($row = mysqli_fetch_assoc($result)) { 
         
        echo "<tr>"; 
        echo "<td><a href=edit_car_form.php?id=".$row[$columnNames[0]].">Edit</a></td>";
        echo "<td><a href=delete_car.php?id=".$row[$columnNames[0]].">Usuń</a></td>";
        foreach ($row as $value) { 
            echo "<td>$value</td>"; 
        } 
        echo "</tr>"; 
    } 
    echo "</table>";
    } else {
        echo "0 results";
    }
    if(isset($_POST['add'])){
        $nazwa = strip_tags($_POST['nazwa']);
        $typ = strip_tags($_POST['typ']);
        
        $sql = "ALTER TABLE samochody ADD $nazwa $typ";
    
        if(mysqli_query($connect,$sql)){
            echo "New colummn was created succesfully";
        }else {
            echo "Error while adding ";
        }
        header("Location: index.php");
    }
    if(isset($_POST['delete'])){
        $nazwa = strip_tags($_POST['nazwa']);
        
        $sql = "ALTER TABLE samochody DROP COLUMN $nazwa";
    
        if(mysqli_query($connect,$sql)){
            echo "Colummn was deleted succesfully";
        }else {
            echo "Error while deleting colummn";
        }
        header("Location: index.php");
    }
    if(isset($_POST['change'])){
        $col1 = strip_tags($_POST['col1']);
        $col2 = strip_tags($_POST['col2']);
        $typ = strip_tags($_POST['typ']);

        $sql = "ALTER TABLE samochody CHANGE $col1 $col2 $typ;";
    
        if(mysqli_query($connect,$sql)){
            echo "Column was swaped succesfully";
        }else {
            echo "Error while swaping column";
        }
        header("Location: index.php");
    }
?>
<div class = "adjust">
<form class = "panel" action="<?php echo $_SERVER['PHP_SELF'];?>" method= "POST">
<h3>Dodaj kolumnę :</h3>
<div class = "inputadjust"
>
    <input type="text" name="nazwa" placeholder= "Nazwa kolumny">
    <br>
    <select name="typ">
    <option value="INT"> INT </option>
    <option value="TEXT"> TEXT </option>
    <option value="DATE"> DATE </option>
</select>
</div>
    <input type="submit" class="smallbutton" name="add" value="Dodaj">
</form>
<form class = "panel" action="<?php echo $_SERVER['PHP_SELF'];?>" method= "POST">
<h3>Usuń kolumnę :</h3>
<div class = "inputadjust"
>
    <input type="text" name="nazwa" placeholder= "Nazwa kolumny">
</div>
    <input type="submit" class="smallbutton" name="delete" value="Usuń">
</form>
<form class = "panel" action="<?php echo $_SERVER['PHP_SELF'];?>" method= "POST">
<h3>Zamień kolumny miejscami:</h3>
<div class = "inputadjust">
<select name="col1">
    <option value= "<?php echo $columnNames[1]?>"> <?php echo $columnNames[1] ?> </option>
    <option value= "<?php echo $columnNames[2]?>"> <?php echo $columnNames[2] ?> </option>
    <option value= "<?php echo $columnNames[3]?>"> <?php echo $columnNames[3] ?> </option>
    <option value= "<?php echo $columnNames[4]?>"> <?php echo $columnNames[4] ?> </option>
</select>
<br>
<input type = "text" name="col2" placeholder="wpisz nazwę na którą chcesz zamienić">
<select name="typ">
    <option value="INT"> INT </option>
    <option value="TEXT"> TEXT </option>
    <option value="DATE"> DATE </option>
    <option value="VARCHAR(11)"> VARCHAR </option>
    <option value="DATE"> DATE </option>
</select>
</div>
    <input type="submit" class="smallbutton" name="change" value="Zamień">
</form>
</div>
<button type="button" class="button" onclick="location.href= 'index.php' ">powrót</button>
</div>
</body>
</html>
