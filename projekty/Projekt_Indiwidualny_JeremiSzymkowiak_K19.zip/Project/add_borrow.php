<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project_bd_jeremi</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.google.com/specimen/Roboto?query=roboto' rel='stylesheet' type='text/css'>
</head>
<body>
<?php

include('bd.php');

if(isset($_POST['add'])){

        
        $id = strip_tags($_POST['id']);
        $Data_wypozyczenia = strip_tags($_POST['datew']);
        $Data_zwrotu = strip_tags($_POST['datez']);
        $Nr_rejestracyjny = strip_tags($_POST['register']);
        $Id_klienta = strip_tags($_POST['idklienta']);

    $sql = "INSERT INTO wypozyczenia (Id_wypozyczenia, Nr_rejestracyjny, Data_wypozyczenia, Data_zwrotu, Id_Klienta) VALUES  ('$id', '$Nr_rejestracyjny', '$Data_wypozyczenia', '$Data_zwrotu', '$Id_klienta')";

    if(mysqli_query($connect,$sql)){
        echo "New record was created succesfully";
    }else {
        echo "Error while addint sccesfully";
    }
    header("Location: index.php");
}

mysqli_close($connect)
?>

<form class = "panel" action="<?php echo $_SERVER['PHP_SELF'];?>" method= "POST">
<h1>Dodaj wypozyczenie :</h1>
<div class = "inputadjust"
>
    <input type="text" name="id" placeholder= "Id wypozyczenia" maxlength = "4">
    <br>
    <input type="text" name="datew" placeholder="Data wypozyczenia">
    <br>
    <input  type="text" name = "datez" placeholder="Data zwrotu">
    <br>
    <h3>Proszę o numer rejestracyjny z istniejących samochodów w bazie</h3>
    <input  type="text" name = "register" placeholder="Nr rejestracyjny " maxlength = "5">
    <h3>Proszę o Id klienta z istniejących klientów w bazie</h3>
    <input  type="text" name = "idklienta" placeholder="Id klienta " maxlength = "1">
</div>
<div class = "adjust">
    <input type="submit" class="button" name="add" value="Dodaj">
    
<button type="button" class="button" onclick="location.href= 'edit_ppl.php' ">powrót</button>
</div>

</body>
</html>