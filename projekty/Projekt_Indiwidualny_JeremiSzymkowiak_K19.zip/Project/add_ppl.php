<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project_bd_jeremi</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.google.com/specimen/Roboto?query=roboto' rel='stylesheet' type='text/css'>
</head>
<body>
<?php
include('bd.php');

if(isset($_POST['add'])){
    $Imie = strip_tags($_POST['Imie']);
    $Nazwisko = strip_tags($_POST['Nazwisko']);
    $NR_telefonu = strip_tags($_POST['NR_telefonu']);
    
    $sql = "INSERT INTO klienci (Imie, Nazwisko, NR_telefonu) VALUES  ('$Imie', '$Nazwisko', '$NR_telefonu')";

    if(mysqli_query($connect,$sql)){
        echo "New record was created succesfully";
    }else {
        echo "Error while addint sccesfully";
    }
    header("Location: index.php");
}

mysqli_close($connect)
?>

<form class = "panel" action="<?php echo $_SERVER['PHP_SELF'];?>" method= "POST">
<h1>Dodaj klienta :</h1>
<div class = "inputadjust"
>
    <input type="text" name="Imie" placeholder= "Imie">
    <br>
    <input type="text" name="Nazwisko" placeholder="Nazwisko">
    <br>
    <input  type="text" name = "NR_telefonu" placeholder="NR_telefonu" maxlength = "9">
</div>
<div class = "adjust">
    <input type="submit" class="button" name="add" value="Dodaj">
    
<button type="button" class="button" onclick="location.href= 'edit_ppl.php' ">powrót</button>
</div>



</body>
</html>