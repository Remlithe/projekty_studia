<!DOCTYPE html>
<html lang="en">
<head>
<style>
body {
    display:flex;
    justify-content: center;
}

</style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project_bd_jeremi</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.google.com/specimen/Roboto?query=roboto' rel='stylesheet' type='text/css'>
</head>
<body>
    <div class ="popup">
<form class = "login" action="<?php echo $_SERVER['PHP_SELF'];?>" method= "POST">
<h3>Zaloguj się</h3>
<div class = "inputadjust">
    <label>Username: <input type="text" name="username"></label><br>
    <label>Password: <input type="password" name="password"></label>
</div>
<div class="adjust">
    <input type="submit" class="button" name="login" value="Zaloguj">
    <button type="button" class="button" onclick="location.href= 'front_page.php' ">powrót</button>
</div>
</form>
<?php
include ("bd.php");
if(isset($_POST['login'])){
$username = $_POST['username'];
$password = $_POST['password'];

if (empty($username) || empty($password)) {
    echo "Username and password are required.";
}else{
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($connect, $sql);
if($user = mysqli_fetch_assoc($result)){

     

if ($password == $user['password']) {
     session_start();
     $_SESSION['username'] = $user['username'];
     header('Location: index.php');
    } else {
    echo "Incorrect password.";
    }
   

}else{
    echo "Wrong user.";
}
}
}
?>
</div>
</body>
</html>
