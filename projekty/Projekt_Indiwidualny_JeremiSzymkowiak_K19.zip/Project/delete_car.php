<?php
include('bd.php');

if(isset($_GET['id'])){
    $id=$_GET['id'];
    $sql = "DELETE FROM samochody WHERE Nr_rejestracyjny=$id";
    if(mysqli_query($connect, $sql)){
        echo "the row was deleted";
    } else
    {
        echo "An error accured in the middle of deleting the row";
    }
}
mysqli_close($connect);
?>
<br>
<a href="index.php">Strona główna</a>