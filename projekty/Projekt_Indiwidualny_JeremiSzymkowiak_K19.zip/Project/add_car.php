<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project_bd_jeremi</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.google.com/specimen/Roboto?query=roboto' rel='stylesheet' type='text/css'>
</head>
<body>
<?php
include('bd.php');

if(isset($_POST['add'])){

        $Nr_rejestracyjny = strip_tags($_POST['register']);
        $Model = strip_tags($_POST['model']);
        $Marka = strip_tags($_POST['marka']);
        $Data_produkcji = strip_tags($_POST['date']);
        $Czy_dostepny = strip_tags($_POST['aviable']);

    $sql = "INSERT INTO samochody (Nr_rejestracyjny, Model, Marka, Rok_produkcji, Czy_Dostepny) VALUES  ('$Nr_rejestracyjny', '$Model', '$Marka', '$Data_produkcji', '$Czy_dostepny')";

    if(mysqli_query($connect,$sql)){
        echo "New record was created succesfully";
    }else {
        echo "Error while addint sccesfully";
    }
    header("Location: index.php");
}

mysqli_close($connect)
?>

<form class = "panel" action="<?php echo $_SERVER['PHP_SELF'];?>" method= "POST">
<h1>Dodaj samochód :</h1>
<div class = "inputadjust">
    
    <input  type="text" name = "register" placeholder="Nr rejestracyjny " maxlength = "5">
    <br>
    <input type="text" name="model" placeholder= "Model">
    <br>
    <input type="text" name="marka" placeholder="Marka">
    <br>
    <input  type="text" name = "date" placeholder="Data produkcji">
    <br>
    <input  type="text" name = "aviable" placeholder="Czy dostepny Tak/Nie" maxlength = "3">
</div>
<div class = "adjust">
    <input type="submit" class="button" name="add" value="Dodaj">
    
<button type="button" class="button" onclick="location.href= 'edit_ppl.php' ">powrót</button>
</div>



</body>
</html>