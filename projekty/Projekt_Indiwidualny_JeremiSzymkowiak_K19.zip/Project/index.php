<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project_bd_jeremi</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.google.com/specimen/Roboto?query=roboto' rel='stylesheet' type='text/css'>
    <div class="header"><h3> PANEL ADMINISTRACYJNY </h3></div> 
    <div class = "head"><button type="button" class="button" onclick="location.href= 'front_page.php' ">wyloguj się</button></div>
</head>
<body>

 
<div class = "container">
    <div class="panel panel-1"> 
    <div class ="text"> Klienci </div>
    <div class = "adjust">
    <button type="button" class="button" onclick="location.href= 'http://localhost/project/add_ppl.php' ">Dodaj klienta</button>
    <button type="button" class="button" onclick="location.href= 'http://localhost/project/edit_ppl.php' ">Wyświetl i edytuj dane</button>
    </div>
    </div>
    <div class="panel panel-2"> 
        <div class ="text"> Samochody </div>
    <div class = "adjust">
    <button type="button" class="button" onclick="location.href= 'http://localhost/project/add_car.php' ">Dodaj samochód</button>
    <button type="button" class="button" onclick="location.href= 'http://localhost/project/edit_car.php' ">Wyświetl i edytuj dane</button>
    </div> 
    </div>
    <div class="panel panel-3"> 
        <div class ="text"> Wypożyczenia </div>
    <div class = "adjust">
    <button type="button" class="button" onclick="location.href= 'http://localhost/project/add_borrow.php' ">Dodaj wypożyczenie</button>
    <button type="button" class="button" onclick="location.href= 'http://localhost/project/edit_borrow.php' ">Wyświetl i edytuj dane</button>
    </div>
    </div>  
</div>


</body>
</html>

