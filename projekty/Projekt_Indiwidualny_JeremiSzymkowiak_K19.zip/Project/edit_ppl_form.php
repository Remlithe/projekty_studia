<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project_bd_jeremi</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.google.com/specimen/Roboto?query=roboto' rel='stylesheet' type='text/css'>
</head>
<body>
<?php

include('bd.php');



if(isset($_GET['id'])){
    $id =$_GET['id'];
    $query = "SELECT * FROM klienci WHERE Id_Klienta = $id";
    $result =  mysqli_query($connect, $query);
    $row = mysqli_fetch_assoc($result);
    $fields = mysqli_fetch_fields($result);
    foreach($fields as $field){
        $columnNames[]= $field->name;
    }
}
else
    {
        echo "An error accured";
    }

    if(isset($_POST['Edit']) ){
        $id = $_POST['id'];
        $Imie = strip_tags($_POST['Imie']);
        $Nazwisko = strip_tags($_POST['Nazwisko']);
        $NR_telefonu = strip_tags($_POST['NR_telefonu']);
        
            $sql = "UPDATE klienci SET Imie = '$Imie', Nazwisko = '$Nazwisko', NR_telefonu = '$NR_telefonu' WHERE Id_Klienta = $id";
        

        if(mysqli_query($connect,$sql)){
            echo "Record was edited succesfully";
        }else {
            echo "Error while editing sccesfully";
        }
        header("Location: edit_ppl.php");
    }
 
?>


<form class = "panel" action="<?php echo $_SERVER['PHP_SELF'];?>" method= "POST">
<h1>Edycja klienta :</h1>
<div class = "inputadjust"
>
    <input type="text" name="Imie" value= "<?php echo $row[$columnNames[1]];?>">
    <br>
    <input type="text" name="Nazwisko" value="<?php echo $row[$columnNames[2]];?>">
    <br>
    <input  type="text" name = "NR_telefonu" value="<?php echo $row[$columnNames[3]];?>" maxlength = "9">
    <br>
    <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>"> 
</div>
<div class = "adjust">
    <input type="submit" class="button" name="Edit" value="Finish">
    
<button type="button" class="button" onclick="location.href= 'edit_ppl.php' ">powrót</button>
</div>

</from>
</body>
</html>
