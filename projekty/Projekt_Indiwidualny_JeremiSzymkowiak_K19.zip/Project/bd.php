<?php
$connect = mysqli_connect('localhost', 'root', '', 'project_bd_jeremi');
?>