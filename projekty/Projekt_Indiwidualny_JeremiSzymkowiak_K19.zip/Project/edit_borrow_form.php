<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>project_bd_jeremi</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://fonts.google.com/specimen/Roboto?query=roboto' rel='stylesheet' type='text/css'>
</head>
<body>
<?php

include('bd.php');

if(isset($_GET['id'])){
    $id =$_GET['id'];
    $query = "SELECT * FROM wypozyczenia WHERE Id_wypozyczenia = '$id'";
    $result =  mysqli_query($connect, $query);
    $row = mysqli_fetch_assoc($result);
    $fields = mysqli_fetch_fields($result);
    foreach($fields as $field){
        $columnNames[]= $field->name;
    }
}
else
    {
        echo "An error accured";
    }

    if(isset($_POST['Edit']) ){
        $id = $_POST['id'];
        $Data_wypozyczenia = strip_tags($_POST['datew']);
        $Data_zwrotu = strip_tags($_POST['datez']);
        
            $sql = "UPDATE wypozyczenia SET Data_wypozyczenia = '$Data_wypozyczenia', Data_zwrotu = '$Data_zwrotu' WHERE Id_wypozyczenia = '$id'";
        
    
        if(mysqli_query($connect,$sql)){
            echo "Record was edited succesfully";
        }else {
            echo "Error while editing sccesfully";
        }
        header("Location: edit_borrow.php");
    }
 
?>


<form class = "panel" action="<?php echo $_SERVER['PHP_SELF'];?>" method= "POST">
<h1>Edycja wypozyczenia :</h1>
<div class = "inputadjust">
    <input type="text" name="datew" value="<?php echo $row[$columnNames[2]];?>" >
    <br>
    <input  type="text" name = "datez" value="<?php echo $row[$columnNames[3]];?>">
    <br>
    <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>"> 
</div>
<div class = "adjust">
    <input type="submit" class="button" name="Edit" value="Finish">
    
<button type="button" class="button" onclick="location.href= 'edit_borrow.php' ">powrót</button>
</div>

</from>
</body>
</html>
